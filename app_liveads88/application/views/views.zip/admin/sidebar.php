 <div class="col-md-3 left_col">
        <div class="left_col scroll-view">

          <div class="navbar nav_title" style="border: 0;">
            <a href="<?php echo base_url();?>" class="site_title"><i class="fa fa-home"></i> <span>BPLife</span></a>
          </div>
          <div class="clearfix"></div>

         

          <!-- sidebar menu -->
          <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">

            <div class="menu_section">
              <ul class="nav side-menu">
				 <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-bar-chart"></i>Dashboard</a>
				 <li><a href="<?php echo base_url();?>customer"><i class="fa fa-user"></i>Customers</a>
				 <li><a href="<?php echo base_url();?>user"><i class="fa fa-users"></i>Users</a>
				  <li><a href="<?php echo base_url();?>event"><i class="fa fa-institution"></i>Events</a>
				  <li><a href="<?php echo base_url();?>job"><i class="fa fa-laptop"></i>Jobs</a>
				  <li><a href="<?php echo base_url();?>product"><i class="fa fa-briefcase"></i>Products</a>
				  <li><a href="<?php echo base_url();?>coupon"><i class="fa fa-fax"></i>Coupons</a>
				  <li><a href="<?php echo base_url();?>splash"><i class="fa fa-fax"></i>Splash</a>
				  <li><a href="<?php echo base_url();?>flashnews"><i class="fa fa-newspaper-o"></i>Flash News</a>
               
              </ul>
            </div>
           

          </div>
          <!-- /sidebar menu -->

     
          <!-- /menu footer buttons -->
        </div>
</div>
<div class="top_nav">
        <div class="nav_menu">
          <nav role="navigation" class="">
            <div class="nav toggle">
              <a id="menu_toggle"><i class="fa fa-bars"></i></a>
            </div>           
          </nav>
        </div>
</div>

     