
<div class="right_col" role="main">
 
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>
                   Add Coupon
                </h3>
            </div>
 
        </div>
        <div class="clearfix"></div>
 
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_content">
				 <?php echo $this->session->flashdata('msg'); ?>
                  <br>
                  <form class="form-horizontal form-label-left" method="POST" action="<?php echo base_url(); ?>coupon/add" id="coupon_form" enctype="multipart/form-data">
					<div class="form-group">
                      <label for="title" class="control-label col-md-3 col-sm-3 col-xs-12">Customer <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="text" class="form-control col-md-7 col-xs-12"  id="customer" name="customer">                     
					  <?php echo form_error('customer_id');?> 
							 
					 </div>
                    </div>
					<div class="form-group">
                      <label for="title" class="control-label col-md-3 col-sm-3 col-xs-12">Coupon Name <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="text" class="form-control col-md-7 col-xs-12"  id="title" name="cp_name" value="<?php echo set_value('cp_name'); ?>">                     
					  <?php echo form_error('cp_name');?> 
					</div>
					</div>
				

					
					<div class="form-group">
                      <label for="location" class="control-label col-md-3 col-sm-3 col-xs-12">Validate Date From<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="text" class="form-control col-md-7 col-xs-12"  name="cp_valid_from" id="valid_date_from"  value="<?php echo set_value('cp_valid_from'); ?>">
						<?php echo form_error('cp_valid_from');?> 
					 </div>
                    </div>
					
					<div class="form-group">
                      <label for="location" class="control-label col-md-3 col-sm-3 col-xs-12">Validate Date To<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="text" class="form-control col-md-7 col-xs-12"  name="cp_valid_to" id="valid_date_to"  value="<?php echo set_value('cp_valid_to'); ?>">
						<?php echo form_error('cp_valid_to');?> 
					 </div>
                    </div>
					
					
                    
					<div class="form-group">
                      <label for="location" class="control-label col-md-3 col-sm-3 col-xs-12">Quantity <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="text" class="form-control col-md-7 col-xs-12"  id="quantity" name="cp_quantity"  value="<?php echo set_value('cp_quantity'); ?>">
                        <?php echo form_error('cp_quantity');?> 
					  </div>
                    </div>
					
					<div class="form-group" id="cp_code_wrapper">
                      <label for="location" class="control-label col-md-3 col-sm-3 col-xs-12">Coupon Code <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="text" class="form-control col-md-7 col-xs-12"  id="coupon_code" name="cp_code" value="<?php echo ((isset($coupon_code) && $coupon_code !="") ? $coupon_code :  set_value('cp_code'));?>">
                        <?php echo form_error('cp_code');?> 
					  </div>
                    </div>
									
					
					
					
					<div class="form-group">
					  <label for="location" class="control-label col-md-3 col-sm-3 col-xs-12">Feature Date From<span class="required">*</span>
					  </label>
					  <div class="col-md-6 col-sm-6 col-xs-12">
						<input type="text" class="form-control col-md-7 col-xs-12"  name="paid_ads_start_date" id="paid_ads_start_date"  value="<?php echo set_value('paid_ads_start_date'); ?>">
						<?php echo form_error('paid_ads_start_date');?> 
					 </div>
					</div>
					
					<div class="form-group">
					  <label for="location" class="control-label col-md-3 col-sm-3 col-xs-12">Feature Date To<span class="required">*</span>
					  </label>
					  <div class="col-md-6 col-sm-6 col-xs-12">
						<input type="text" class="form-control col-md-7 col-xs-12"  name="paid_ads_end_date" id="paid_ads_end_date"  value="<?php echo set_value('paid_ads_end_date'); ?>">
						<?php echo form_error('paid_ads_end_date');?> 
					 </div>
					</div>
					
					<div class="form-group">
                      <label for="location" class="control-label col-md-3 col-sm-3 col-xs-12">Image <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
						<input type="file" name="cp_image" size="20" accept="image/*"  id="file_select"/>
						<img id="output" width="100" height="100" />
						<?php echo form_error('cp_image');?>    </div>
                    </div>
					<div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Description<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <textarea class="mceEditor" rows="3" class="form-control col-md-7 col-xs-12" name="cp_description"> <?php echo set_value('cp_description'); ?></textarea>
						 <?php echo form_error('cp_description');?> 
                      </div>
                    </div>
					<input type='hidden' name='customer_id' id='customer_id' />
					<div class="pull-right">
					<a href="<?php echo base_url(); ?>coupon" class="btn btn-primary">Back to List</a>
					<input class="btn btn-success" type="submit" value="Submit">
					</div>
                  </form>
                </div>
              </div>
            </div>
          </div>
    </div>
</div>
<div id="dialog-1" style="display:none">File size is greater than 5MB</div>
  <script>
 $(function() {
	   
		$("#cp_code_wrapper").css("display","none");
		$("#quantity").blur(function(){
			var quantity = $("#quantity").val();
			if(quantity != "" && quantity > 0 && (quantity >>> 0 === parseFloat(quantity))){
				$('#cp_code_wrapper').css("display","block");
			}else{
				$("#cp_code_wrapper").css("display","none");
			}
		});
		
		var quantity = $("#quantity").val();
		if(quantity != "" && quantity > 0 && (quantity >>> 0 === parseFloat(quantity))){
			$('#cp_code_wrapper').css("display","block");
		}else{
			$("#cp_code_wrapper").css("display","none");
		}
	 
	 
	 
       $('#valid_date_from').datepicker({
			dateFormat: "yy-mm-dd",
		    onClose: function( selectedDate ) {
				$( "#valid_date_to" ).datepicker( "option", "minDate", selectedDate );
			  }
       });
	   
	   $('#valid_date_to').datepicker({
			dateFormat: "yy-mm-dd",
		    onClose: function( selectedDate ) {
				$( "#valid_date_from" ).datepicker( "option", "maxDate", selectedDate );
			  }
       });
	   
	     $('#paid_ads_start_date').datepicker({
			dateFormat: "yy-mm-dd",
			onClose: function( selectedDate ) {
				$( "#paid_ads_end_date" ).datepicker( "option", "minDate", selectedDate );
			  }
		});

		$('#paid_ads_end_date').datepicker({
			dateFormat: "yy-mm-dd",
			onClose: function( selectedDate ) {
				$( "#paid_ads_start_date" ).datepicker( "option", "maxDate", selectedDate );
			  }
		});
    });

  </script>
  <script>

  $(function(){
	   $("#customer").autocomplete({
	 source: function (request, response) {
		$.ajax({
			url: "<?php echo base_url();?>customer/getCustomer",
			dataType: "json",
			type: "GET",
			data: {
				term: request.term
			},
			success: function(data) {
				response($.map(data, function(item) {
					return {
						label: item.label,
						value: item.value,
						id: item.id
					};
				}));
			},
			error: function(xhr) {
				alert("please select customer");
			}
		});
	},
	focus: function( event, ui ) {
	   $( "#customer" ).val( ui.item.label );
		return false;
	  },
	select: function(event, ui) {
	  $( "#customer_id" ).val( ui.item.id );
	  return false;
	}
});
});
</script>
<script>

$("#file_select").change(function (e) {
	var file_size = $('#file_select')[0].files[0].size;
	if(file_size>52428880) {
		 $("#dialog-1").dialog();;
		return false;
	}else{
   var output = document.getElementById('output');var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('output');
      output.src = reader.result;
    };
    reader.readAsDataURL(e.target.files[0]);
    }
 
});

</script>