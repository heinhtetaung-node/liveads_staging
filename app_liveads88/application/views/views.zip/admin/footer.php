	 <!-- footer content -->
      <footer>
        <div class="pull-right">
          © 2016 Powered by  <a href="http://www.sgdatahub.com">www.sgdatahub.com</a>
        </div>
        <div class="clearfix"></div>
      </footer>
      <!-- /footer content -->
	</div>
</div>
<script src="<?php echo base_url();?>assets/js/jquery-ui.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/admin_custom.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/js/tinymce/tinymce.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.confirm.min.js"></script>


	
	
<script type="text/javascript">
  tinymce.init({
    mode : "specific_textareas",
    editor_selector : "mceEditor",
    });
</script>

</body>
</html>