<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
  * User Module
  *
  * This module is for user function.
  *	@EI EI 
  * @return void
  */
class User extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		$this->load->model('User_model');
		$this->load->library(array('form_validation','session','pagination'));
        $this->load->helper(array('url','html','form'));
		
		if($this->session->userdata('isLogin') && $this->session->userdata('user_level') == 'admin' &&  $this->session->userdata('admin_id') > 0 ){
			// authorize
		}else{
			redirect('Admin/login');
		}
	}
	
	 /**
    * Add about splash list
    * @Ei
    */
	function index(){
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/user/list');
		$this->load->view('admin/footer');
	}
	
	
	 /**
    * user datatable
    * @Ei
    */
	public function user_datatable(){
		$requestData= $_REQUEST;
 
		$columns = array( 
			0 =>'user_created_date',	
			);	
			
		$sql = "SELECT
				`user`.user_id,
				`user`.user_email,
				`user`.user_email,
				`user`.user_name,
				`user`.user_first_name,
				`user`.user_last_name,
				`user`.user_gender,
				`user`.user_country,
				`user`.user_phone,
				`user`.user_active";
		$sql.=" FROM
				`user`";
		if( !empty($requestData['search']['value']) ) {  
			$sql.=" AND ( `user`.user_name LIKE '".$requestData['search']['value']."%' )";    
		}
		$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";

		$query = $this->db->query($sql);
		
		
		$record_count_sql ="SELECT `user`.user_id FROM `user`";
		if( !empty($requestData['search']['value']) ) {  
			$sql.=" AND ( `user`.user_name LIKE '".$requestData['search']['value']."%' )";    
		}
		$record_count_query = $this->db->query($record_count_sql);
		//print_r($query->result());
		$recordsFiltered = $this->db->query("SELECT FOUND_ROWS()")->row(0)->{"FOUND_ROWS()"}; 
		//echo $recordsFiltered;
		$resTotalLength = $this->db->query(
			"SELECT COUNT(*) as rowcount FROM user"

		);
		$recordsTotal = $resTotalLength->row()->rowcount;
		
		$result = $query->result_array();
		$result_array = array();
		foreach ($result as $key => $row) {
			$tmpentry = array();
			$tmpentry[] = $row['user_name'];
			$tmpentry[] = $row['user_email'];					
			$tmpentry[] = $row['user_first_name'];
			$tmpentry[] = $row['user_last_name'];
			$tmpentry[] = $row['user_phone'];
			$tmpentry[] = $row['user_gender'];
			$tmpentry[] = $row['user_country'];
			
	
			$tmpentry[] = "<a href='".base_url()."user/detail/".$row['user_id']."' class='btn btn-info'>Detail</a>";			

			$result_array[] = $tmpentry;
		}
		
		/*
		 * Output
		 */
		$output = array(
			"draw"            => intval( $_GET['draw'] ),
			"recordsTotal"    => intval( $recordsTotal ),
			"recordsFiltered" => intval( $recordsFiltered ),
			"data"            => ($result_array)
		);
		print_r(json_encode($output));
		exit();
	}
	
	
	 /**
    * Detail
    * @Ei
    */
	public function detail(){
		$id = $this->uri->segment(3);
		if(!is_numeric($id)){
			redirect('user');
		}
		if($data['user'] = $this->User_model->getUserById($id)){	
		
			
		//load the view
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/user/detail',$data);
		$this->load->view('admin/footer');	
		}else{
			redirect('user');
		}
	}
}