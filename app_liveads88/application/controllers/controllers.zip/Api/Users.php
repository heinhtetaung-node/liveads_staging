<?php defined('BASEPATH') OR exist('No direct script access allowed');

require APPPATH.'/libraries/REST_Controller.php';
/**
 * This is user system 
 * @author  EI
 *
 */
class Users extends REST_Controller
{
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('User_model');
		$this->lang->load('api', 'english');
    }
	
	/*
	* Api user register
	*URL: api/users/register/format/json
	*{"user_name":"","user_email":"","user_phone":"","user_gender":"","user_password":"","user_country":"","user_first_name":"","user_last_name":"","user_invitation_code":""}
	*/	
	function register_post(){
		if($this->post()){
			$data = array(
					'user_email' 	=> $this->security->xss_clean($this->post('user_email')),
					'user_name' 	=> $this->security->xss_clean($this->post('user_name')),
					'user_password' 		=> $this->security->xss_clean($this->post('user_password')),
					'user_first_name' 		=> $this->security->xss_clean($this->post('user_first_name')),
					'user_last_name' 		=> $this->security->xss_clean($this->post('user_last_name')),
					'user_gender' 		=> $this->security->xss_clean($this->post('user_gender')),
					'user_country' 		=> $this->security->xss_clean($this->post('user_country')),
					'user_phone' 		=> $this->security->xss_clean($this->post('user_phone')),
					'user_verification_code' => rand(1000, 9999),
					);
			$error_result = $this->_validate_register_request($data);
			if(count($error_result) > 0){
				$response = array("status"=>array("code"=>400,"message"=>$error_result));
				$this->response($response, 200);
			}else{
				$data['user_password'] 	= hash('sha256',$data['user_password']);
				if($this->User_model->apiCheckMobileExist($this->security->xss_clean($this->post('user_phone')))){
					$response = array("status"=>array("code"=>406,"message"=> $this->lang->line('api_reg_phone_exists') ));
					$this->response($response, 200);
				}
				if($this->User_model->apiCheckEmailExist($this->security->xss_clean($this->post('user_email')))){
					$response = array("status"=>array("code"=>407,"message"=> $this->lang->line('api_reg_email_exists') ));
					$this->response($response, 200);
				}
				if($this->post('user_invitation_code') !=""){
					if(!$this->User_model->apiCheckInvitation($data['user_email'],$this->security->xss_clean($this->post('user_invitation_code')))){
						$response = array("status"=>array("code"=>408,"message"=> "Invalid invitation code!"));
						$this->response($response, 200);
					}					
				}
				
				if($id = $this->User_model->apiRegister($data,$this->security->xss_clean($this->post('user_invitation_code')))){
					$response = array("status"=>array("code"=>200, "user_id"=>$id,"message"=> $this->lang->line('api_reg_success') ));
					$this->response($response, 200);		
				}else{
					$response = array("status"=>array("code"=>203,"message"=> $this->lang->line('api_reg_fail') ));
					$this->response($response, 200); 
				}
			}
		}else{
			$response =array("status"=> array("code"=>403,"message"=> $this->lang->line('api_invalid_access') ));
			$this->response($response, 200); 
		}
	}
	
	function _validate_register_request($data){
		$error_list = array();
		if ((strlen($data['user_email']) > 96) || !filter_var($data['user_email'], FILTER_VALIDATE_EMAIL)) {
				$error_list['user_email']= $this->lang->line('api_reg_invalid_email');
			}
		if($data['user_phone']==""){
			$error_list['user_phone'] = $this->lang->line('api_reg_phone_required');
		}else if(strlen($data['user_phone']) < 6){
			$error_list['user_phone'] = $this->lang->line('api_reg_phone_invalid');
		}else if(!$this->_validatePositiveNumber($data['user_phone'])){
			$error_list['user_phone'] = $this->lang->line('api_reg_phone_invalid');
		}
		
		if($data['user_name']==""){
			$error_list['user_name'] = $this->lang->line('api_reg_name_required');
		}else if(strlen($data['user_name']) < 3 ){
			$error_list['user_name'] = $this->lang->line('api_reg_name_minimun');
		}
		
		if ((strlen($data['user_password']) < 6) || (strlen($data['user_password']) > 32)) {
				$error_list['user_password'] =$this->lang->line('api_reg_pass_minimun');
			}
		
		if($data['user_first_name']==""){
			$error_list['user_first_name'] = $this->lang->line('api_reg_first_name_required');
		}else if(strlen($data['user_name']) < 3 ){
			$error_list['user_first_name'] = $this->lang->line('api_reg_first_name_minimun');
		}
		
		if($data['user_last_name']==""){
			$error_list['user_last_name'] = $this->lang->line('api_reg_last_name_required');
		}else if(strlen($data['user_last_name']) < 3 ){
			$error_list['user_last_name'] = $this->lang->line('api_reg_last_name_minimun');
		}
		
		if($data['user_gender']==""){
			$error_list['user_gender'] = $this->lang->line('api_reg_gender_required');
		}
		
		if($data['user_country']==""){
			$error_list['user_country'] = $this->lang->line('api_reg_country_required');
		}
		return $error_list;
	}
	
	/*
	* Api user verification
	* URL: api/users/verification/format/json
	*{"user_id":"","user_verification_code":""}
	*/
	function verification_post(){
		if($this->post()){
			$user_id = $this->security->xss_clean($this->post('user_id'));
			$code = $this->security->xss_clean($this->post('user_verification_code'));
			if($this->User_model->apiCheckVerifi($user_id,$code)){
			 $response = array("status"=>array("code"=>200, "message"=> $this->lang->line('api_veri_success') ));
				$this->response($response, 200);		
			}else{
				$response = array("status"=>array("code"=>203,"message"=> $this->lang->line('api_veri_fail') ));
				$this->response($response, 200); 
			}
		}else{
			$response =array("status"=> array("code"=>403,"message"=> $this->lang->line('api_invalid_access') ));
			$this->response($response, 200); 
		}
	}
	
	/*
	* Api user login
	* URL: api/users/login/format/json
	*{"user":"","user_password":""}
	*/
	function login_post(){
		if($this->post()){
			$user 			= $this->security->xss_clean($this->post('user'));			
			$user_password 	=  hash('sha256',$this->security->xss_clean($this->post('user_password')));
			$error_result = $this->_validate_login_request($this->post('user'),$this->post('user_password'));
			if(count($error_result) > 0){
				$response = array("status"=>array("code"=>400,"message"=>$error_result));
				$this->response($response, 200);
			}else{
				if($user = $this->User_model->apiLogin($user,$user_password )){
					$response = array("status"=>array(
									"code"			=>200,
									"message"		=> $this->lang->line('api_login_success') ,
									"user_id"=>$user['user_id'],			
									"user_name"=>$user['user_name'],
									"user_email"=>$user['user_email'],
									"user_phone"=>$user['user_phone'],
									"user_first_name"=>$user['user_first_name'],
									"user_last_name"=>$user['user_last_name'],
									"user_country"=>$user['user_country'],
									"user_gender"=>$user['user_gender'],							
									"user_active"=>$user['user_active'],							
									"user_newletter_status"=>$user['user_newletter_status'],							
									"user_token"=>$user['token'],							
							));
					$this->response($response, 200); // 200 being the HTTP response code	
				}else{
					$response = array("status"=>array("code"=>203,"message"=> $this->lang->line('api_login_fail') ));
					$this->response($response, 200); 
				}
			}
		}else{
			$response =array("status"=> array("code"=>403,"message"=> $this->lang->line('api_invalid_access') ));
			$this->response($response, 200); 
		}
	}
	
	function _validate_login_request($user,$user_password){
		$error_list = array();
		if($user ==""){
			$error_list['user'] = $this->lang->line('api_veri_user_required');
		}
		
		if($user_password==""){
			$error_list['user_password'] = $this->lang->line('api_veri_pass_required');
		}
		return $error_list;
	}
	
	/*
	* Api user password
	* URL: api/users/password/format/json
	*{"user_token":"","user_old_password":"","user_new_password":""}
	*/
	function password_post(){
		if($this->post()){
			$data = array(
				'token' 		=> trim($this->security->xss_clean($this->post('user_token'))),
				'old_password'	=> trim($this->security->xss_clean($this->post('user_old_password'))),
				'password' 		=> trim($this->security->xss_clean($this->post('user_new_password'))),
			);
			$error_result = $this->_validateChangePasswordrequest($data);
			if(count($error_result) > 0){
				$response = array("status"=>array("code"=>400,"message"=>$error_result));
				$this->response($response, 200);
			}else{
				if($user_id = $this->User_model->check_token($data)){
					$data['old_password'] 	= hash('sha256',$data['old_password']);
					$data['password'] 		= hash('sha256',$data['password']);
					if($this->User_model->check_oldPassword($data, $user_id)){
						if($updated_token = $this->User_model->api_updatePassword($data, $user_id)){
							$response =array("status"=> array("code"=>200,"message"=> $this->lang->line('api_chp_success') , "token"=>$updated_token ));
							$this->response($response, 200);
						}else{
							$response =array("status"=> array("code"=>203,"message"=> $this->lang->line('api_chp_fail') ));
							$this->response($response, 200);	
						}
					}else{
						$response =array("status"=> array("code"=>406,"message"=> $this->lang->line('api_chp_icorrect_old_password') ));
						$this->response($response, 200);
					}
				}else{
					$response =array("status"=> array("code"=>401,"message"=> $this->lang->line('api_invalid_token') ));
					$this->response($response, 200);
				}
			}
		}else{
		$response =array("status"=> array("code"=>403,"message"=> $this->lang->line('api_invalid_access') ));
			$this->response($response, 200); 
		}
	}
	
	
	
	/*
	* Api user inquiry
	* URL: api/users/inquiry/format/json
	*{"user_token":"","user_id":"","user_name":"","user_message":"","image":""}
	*/
	function inquiry_post(){
		if($this->post()){
			$data = array(
				'token' 		=> trim($this->security->xss_clean($this->post('user_token'))),
				'user_id' 		=> trim($this->security->xss_clean($this->post('user_id'))),
				'user_name' 		=> trim($this->security->xss_clean($this->post('user_name'))),
				'user_message' 		=> trim($this->security->xss_clean($this->post('user_message'))),
				'image' 		=> trim($this->security->xss_clean($this->post('image'))),
				);	
				
			$error_result = $this->_validateInquiryrequest($data);
			if(count($error_result) > 0){
				$response = array("status"=>array("code"=>400,"message"=>$error_result));
				$this->response($response, 200);
			}else{
				if($user_id = $this->User_model->check_token($data)){
					if($this->User_model->apiAddInquiry($data)){
						$response = array("status"=>array(
										"code"			=>200,
										"message"		=> "successfully send" ,
																					
								));
						$this->response($response, 200); // 200 being the HTTP response code	
					}else{
						$response =array("status"=> array("code"=>203,"message"=> "Error send"));
						$this->response($response, 200);
					}
				}else{
					$response =array("status"=> array("code"=>401,"message"=> $this->lang->line('api_invalid_token') ));
					$this->response($response, 200);
				}
			}
		}else{
			$response =array("status"=> array("code"=>403,"message"=> $this->lang->line('api_invalid_access') ));
			$this->response($response, 200); 	
		}
	}
	
	/*
	* Api usercount
	* URL: api/users/usercount/format/json
	*
	*/
	function usercount_post(){
		if($total = $this->User_model->apiGetTotalUser($data)){
			$response = array("status"=>array(
							"code"			=>200,
							"total_user"    => $total,
							"message"		=> "successfully send" ,
																		
					));
			$this->response($response, 200); // 200 being the HTTP response code	
		}else{
			$response =array("status"=> array("code"=>203,"message"=> "Error send"));
			$this->response($response, 200);
		}
	}
	
	/*
	* Api flashnews
	* URL: api/users/flashnews/format/json
	*
	*/
	function flashnews_post(){
		if($news = $this->User_model->apiGetFlashNews()){
			$response = array("status"=>array(
							"code"			=>200,
							"data"    => $news,
							"message"		=> "success" ,
																		
					));
			$this->response($response, 200); // 200 being the HTTP response code	
		}else{
			$response =array("status"=> array("code"=>203,"message"=> "Results not found"));
			$this->response($response, 200);
		}
	}
	
	
	/*
	* Api splash
	* URL: api/users/splash/format/json
	*
	*/
	function splash_post(){
		if($splash = $this->User_model->apiGetSplash()){
			$response = array("status"=>array(
							"code"			=>200,
							"data"    => $splash->spimg_image_base64,
							"message"		=> "Results found" ,
																		
					));
			$this->response($response, 200); // 200 being the HTTP response code	
		}else{
			$response =array("status"=> array("code"=>203,"message"=> "Results not found"));
			$this->response($response, 200);
		}
	}
	
	/*
	* Api like 
	* URL: api/users/like/format/json
	*{"user_token":"","user_id":"","id":"","type":""}
	*/
	function like_post(){
		if($this->post()){
			$data = array(
				'token' 		=> trim($this->security->xss_clean($this->post('user_token'))),
				'user_id' 		=> trim($this->security->xss_clean($this->post('user_id'))),
				'id'	=> trim($this->security->xss_clean($this->post('id'))),
				'type' 		=> trim($this->security->xss_clean($this->post('type'))),
			);
			$error_result = $this->_validateLikerequest($data);
			if(count($error_result) > 0){
				$response = array("status"=>array("code"=>400,"message"=>$error_result));
				$this->response($response, 200);
			}else{
				if($user_id = $this->User_model->check_token($data)){
					if($this->User_model->apiLike($data)){
						$response =array("status"=> array("code"=>200,"message"=> "success"));
						$this->response($response, 200);
					}else{
						$response =array("status"=> array("code"=>203,"message"=> "fail" ));
						$this->response($response, 200);	
					}
				}else{
					$response =array("status"=> array("code"=>401,"message"=> $this->lang->line('api_invalid_token') ));
					$this->response($response, 200);
				}
			}
		}else{
			$response =array("status"=> array("code"=>403,"message"=> $this->lang->line('api_invalid_access') ));
			$this->response($response, 200); 
		}
	}
	
	
	function _validateChangePasswordrequest($data){
		$error_list = array();
		
		if($data['token']==""){
			$error_list['token'] = "token required!";
		}else if(!$this->_validateCharacterAndNumber($data['token'])){
			$error_list['token'] = "Invalid token ID!";
		}
		
		if($data['old_password']==""){
			$error_list['old_password'] = $this->lang->line('api_chp_password_required');
		}
		
		if($data['password']==""){
			$error_list['password'] = $this->lang->line('api_chp_password_required');
		}
		
		return $error_list;
	}
	
	function _validateInquiryrequest($data){
		$error_list = array();
		
		if($data['token']==""){
			$error_list['token'] = "token required!";
		}else if(!$this->_validateCharacterAndNumber($data['token'])){
			$error_list['token'] = "Invalid token ID!";
		}
		if($data['user_id']==""){
			$error_list['user_id'] = "user id required!";
		}else if(!$this->_validatePositiveNumber($data['user_id'])){
			$error_list['user_id'] = "Invalid user id ID!";
		}

		if($data['user_name']==""){
			$error_list['user_name'] = "Name required!";
		}
		
		if($data['user_message']==""){
			$error_list['user_message'] = "Message required!";
		}
		
		return $error_list;
	}
	
	function _validateLikerequest($data){
		$error_list = array();
		
		if($data['token']==""){
			$error_list['token'] = "token required!";
		}else if(!$this->_validateCharacterAndNumber($data['token'])){
			$error_list['token'] = "Invalid token ID!";
		}
		if($data['user_id']==""){
			$error_list['user_id'] = "user id required!";
		}else if(!$this->_validatePositiveNumber($data['user_id'])){
			$error_list['user_id'] = "Invalid user id ID!";
		}
		
		if($data['id']==""){
			$error_list['id'] = "item id required!";
		}else if(!$this->_validatePositiveNumber($data['id'])){
			$error_list['id'] = "Invalid item id ID!";
		}
		
		if($data['type']==""){
			$error_list['type'] = "Type required!";
		}
		
		return $error_list;
	}
	
	function _validateBookmarkrequest($data){
		$error_list = array();
		
		if($data['token']==""){
			$error_list['token'] = "token required!";
		}else if(!$this->_validateCharacterAndNumber($data['token'])){
			$error_list['token'] = "Invalid token ID!";
		}
		if($data['user_id']==""){
			$error_list['user_id'] = "user id required!";
		}else if(!$this->_validatePositiveNumber($data['user_id'])){
			$error_list['user_id'] = "Invalid user id ID!";
		}
		
		if($data['bookmark_id']==""){
			$error_list['bookmark_id'] = "bookmark id required!";
		}else if(!$this->_validatePositiveNumber($data['bookmark_id'])){
			$error_list['bookmark_id'] = "Invalid bookmark id ID!";
		}
		
		if($data['type']==""){
			$error_list['type'] = "Type required!";
		}
		
		return $error_list;
	}
	
	function _validateBookmarkListrequest($data){
		$error_list = array();
		
		if($data['token']==""){
			$error_list['token'] = "token required!";
		}else if(!$this->_validateCharacterAndNumber($data['token'])){
			$error_list['token'] = "Invalid token ID!";
		}
		if($data['user_id']==""){
			$error_list['user_id'] = "user id required!";
		}else if(!$this->_validatePositiveNumber($data['user_id'])){
			$error_list['user_id'] = "Invalid user id ID!";
		}
		
		
		
		return $error_list;
	}
	
	function _validatePositiveNumber($value){
		if (!preg_match('/^[0-9]+$/', $value)) {
			return false;
		} else {
			return true;
		}
	}
	function _validateCharacterAndNumber($value){
		if (!preg_match('/^[a-zA-Z0-9-]+$/', $value)) {
			return false;
		} else {
			return true;
		}
	}
}