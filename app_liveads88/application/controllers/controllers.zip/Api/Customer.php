<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
  * Customer Module
  *
  * This module is for Customer function.
  *	@EI EI 
  * @return void
  */
class Customer extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		$this->load->model('Customer_model');
		$this->load->library(array('form_validation','session','pagination'));
        $this->load->helper(array('url','html','form'));
	}
	
	
	function index(){
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/customer/list');
		$this->load->view('admin/footer');
	}
	
	function getCustomer(){
		if (isset($_GET['term'])){
		  $q = strtolower($_GET['term']);
		  $this->Customer_model->getCustomer($q);
		}
	}
	
	 /**
    * Add about customer datatable
    * @Ei
    */
	public function customer_datatable(){
		$requestData= $_REQUEST;
 
		$columns = array( 
			0 =>'cu_created',	
			);	
			
		$sql = "SELECT * ";
		$sql.=" FROM customer WHERE 1=1";
		if( !empty($requestData['search']['value']) ) {  
			$sql.=" AND ( cu_name LIKE '".$requestData['search']['value']."%' )";    
		}
		$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";

		$query = $this->db->query($sql);
		//print_r($query->result());
		$recordsFiltered = $this->db->query("SELECT FOUND_ROWS()")->row(0)->{"FOUND_ROWS()"}; 
		//echo $recordsFiltered;
		$resTotalLength = $this->db->query(
			"SELECT COUNT(*) as rowcount FROM customer"

		);
		$recordsTotal = $resTotalLength->row()->rowcount;
		
		$result = $query->result_array();
		$result_array = array();
		foreach ($result as $key => $row) {
			$tmpentry = array();
			$tmpentry[] = $row['cu_name'];
			$tmpentry[] = $row['cu_email'];
			$tmpentry[] = $row['cu_mobile'];			
			$tmpentry[] = $row['cu_lat'];
			$tmpentry[] = $row['cu_long'];
			$tmpentry[] = ($row['cu_status']==1) ? "active" : "inactive";
			$tmpentry[] = "<a href='".base_url()."customer/update/".$row['cu_id']."' class='btn btn-info'>Edit</a><a href='".base_url()."customer/delete/".$row['cu_id']."' class='btn btn-danger' onclick='return confirm(\"Are you sure?\")'>Delete</a>";			

			$result_array[] = $tmpentry;
		}
		
		/*
		 * Output
		 */
		$output = array(
			"draw"            => intval( $_GET['draw'] ),
			"recordsTotal"    => intval( $recordsTotal ),
			"recordsFiltered" => intval( $recordsFiltered ),
			"data"            => ($result_array)
		);
		print_r(json_encode($output));
		exit();
	}
	
	
	/**
	  *  add customer
	  *
	*/
	public function add()
	{
		if($this->input->server('REQUEST_METHOD') == 'POST'){
			
			 //form validation			
			$this->form_validation->set_rules('cu_name', ' Name', 'required');
			$this->form_validation->set_rules('cu_email', ' Email', 'required');
			$this->form_validation->set_rules('cu_mobile', ' Mobile', 'required');
			$this->form_validation->set_rules('cu_address', 'Address', 'required');
			$this->form_validation->set_rules('cu_postal', 'Postal code', 'required');
	
			$this->form_validation->set_error_delimiters('<span class="error">', '</span>'); 
			if($this->form_validation->run()==FALSE){

				$this->load->view('admin/header');
				$this->load->view('admin/sidebar');
				$this->load->view('admin/customer/add');
				$this->load->view('admin/footer');
			}else{
				 $data_to_store = array(
					'cu_name' => $this->input->post('cu_name'),
					'cu_email' => $this->input->post('cu_email'),
					'cu_mobile' => $this->input->post('cu_mobile'),
					'cu_address' => $this->input->post('cu_address'),
					'cu_postal' => $this->input->post('cu_postal')
				);
				if($this->Customer_model->addCustomer($data_to_store)){
					$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Successfully added</div>');
				}else{
					$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Error saving customer into the system!</div>');
				}
				$this->load->view('admin/header');
				$this->load->view('admin/sidebar');
				$this->load->view('admin/customer/add');
				$this->load->view('admin/footer');
			}
			
		}else{
			$this->load->view('admin/header');
			$this->load->view('admin/sidebar');
			$this->load->view('admin/customer/add');
			$this->load->view('admin/footer');
		}
	}
	
	
	public function update()
	{
		$id = $this->uri->segment(3);
		if($this->input->server('REQUEST_METHOD') == 'POST'){
			
			 //form validation			
			$this->form_validation->set_rules('cu_name', ' Name', 'required');
			$this->form_validation->set_rules('cu_email', ' Email', 'required');
			$this->form_validation->set_rules('cu_mobile', ' Mobile', 'required');
			$this->form_validation->set_rules('cu_address', 'Address', 'required');
			$this->form_validation->set_rules('cu_postal', 'Postal code', 'required');
	
			$this->form_validation->set_error_delimiters('<span class="error">', '</span>'); 
			if($this->form_validation->run()==FALSE){

				$this->load->view('admin/header');
				$this->load->view('admin/sidebar');
				$this->load->view('admin/customer/update');
				$this->load->view('admin/footer');
			}else{
				 $data_to_store = array(
					'cu_name' => $this->input->post('cu_name'),
					'cu_email' => $this->input->post('cu_email'),
					'cu_mobile' => $this->input->post('cu_mobile'),
					'cu_address' => $this->input->post('cu_address'),
					'cu_postal' => $this->input->post('cu_postal')
				);
				if($this->Customer_model->updateCustomer($id, $data_to_store)){
					$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Successfully update customer.</div>');
				}else{
					$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Error updating customer into the system!</div>');
				}
				redirect('customer/update/'.$id.'');
			}
			
		}
		
		
		if($data['customer'] = $this->Customer_model->getCustomerDataById($id)){
		
			//load the view
			$this->load->view('admin/header');
			$this->load->view('admin/sidebar');
			$this->load->view('admin/customer/update', $data);
			$this->load->view('admin/footer');	
		}else{
			redirect('customer');
		}
		
	}
	
}