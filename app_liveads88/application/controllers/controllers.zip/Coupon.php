<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
  * Coupon Module
  *
  * This module is for Coupon function.
  *	@EI EI 
  * @return void
  */
class Coupon extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		$this->load->model('Coupon_model');
		$this->load->library(array('form_validation','session','pagination'));
        $this->load->helper(array('url','html','form'));
	}
	
	 /**
    * Add about coupon list
    * @Ei
    */
	function index(){
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/coupon/list');
		$this->load->view('admin/footer');
	}
	
	
	 /**
    * Add about coupon datatable
    * @Ei
    */
	public function coupon_datatable(){
		$requestData= $_REQUEST;
 
		$columns = array( 
			0 =>'cp_created',	
			);	
			
		$sql = "SELECT customer.cu_name,
				`coupon`.cp_id,
				`coupon`.customer_id,
				`coupon`.cp_name,
				`coupon`.cp_description,
				`coupon`.cp_quantity,
				`coupon`.cp_code,
				`coupon`.cp_valid_from,
				`coupon`.cp_valid_to";
		$sql.=" FROM
				`coupon`
				INNER JOIN customer ON `coupon`.customer_id = customer.cu_id WHERE 1=1";
		if( !empty($requestData['search']['value']) ) {  
			$sql.=" AND ( `coupon`.cp_name LIKE '".$requestData['search']['value']."%' )";    
		}
		$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";

		$query = $this->db->query($sql);
		//print_r($query->result());
		$recordsFiltered = $this->db->query("SELECT FOUND_ROWS()")->row(0)->{"FOUND_ROWS()"}; 
		//echo $recordsFiltered;
		$resTotalLength = $this->db->query(
			"SELECT COUNT(*) as rowcount FROM coupon"

		);
		$recordsTotal = $resTotalLength->row()->rowcount;
		
		$result = $query->result_array();
		$result_array = array();
		foreach ($result as $key => $row) {
			$tmpentry = array();
			$tmpentry[] = $row['cp_name'];
			$tmpentry[] = $row['cu_name'];
			$tmpentry[] = $row['cp_quantity'];			
			$tmpentry[] = $row['cp_description'];
			$tmpentry[] = $row['cp_code'];
			$tmpentry[] = $row['cp_valid_from'];
			$tmpentry[] = $row['cp_valid_to'];
			$tmpentry[] = "<a href='".base_url()."coupon/update/".$row['cp_id']."' class='btn btn-info'>Edit</a><a href='".base_url()."coupon/deleteCoupon/".$row['cp_id']."' class='btn btn-danger' onclick='return confirm(\"Are you sure?\")'>Delete</a>";			

			$result_array[] = $tmpentry;
		}
		
		/*
		 * Output
		 */
		$output = array(
			"draw"            => intval( $_GET['draw'] ),
			"recordsTotal"    => intval( $recordsTotal ),
			"recordsFiltered" => intval( $recordsFiltered ),
			"data"            => ($result_array)
		);
		print_r(json_encode($output));
		exit();
	}
	
	
	/**
	  *  add coupon
	  *
	*/
	public function add()
	{
		if($this->input->server('REQUEST_METHOD') == 'POST'){
			 //form validation			
			$this->form_validation->set_rules('cp_name', ' Coupon Name', 'trim|required');
			$this->form_validation->set_rules('cp_description', ' Description', 'trim|required');
			$this->form_validation->set_rules('cp_quantity', ' Quantity', 'trim|numeric');	
			$this->form_validation->set_rules('cp_code', ' Code', 'trim');	
			$this->form_validation->set_rules('cp_valid_from', ' Valid From', 'trim|required');	
			$this->form_validation->set_rules('cp_valid_to', ' Valid To', 'trim|required');	
			$this->form_validation->set_rules('customer', ' Customer', 'trim|required');	
			$this->form_validation->set_rules('customer_id', ' Customer', 'trim|numeric|required');	
			if (empty($_FILES['cp_image']['name']))
			{
				$this->form_validation->set_rules('cp_image', 'Image', 'required');
			}
			$this->form_validation->set_error_delimiters('<span class="error">', '</span>'); 
			if($this->form_validation->run()==FALSE){
				
				$this->load->view('admin/header');
				$this->load->view('admin/sidebar');
				$this->load->view('admin/coupon/add');
				$this->load->view('admin/footer');
			}else{	
				 $targetPath = getcwd() . '/uploads/coupon/';
				 move_uploaded_file($_FILES["cp_image"]["tmp_name"], $targetPath.$_FILES["cp_image"]["name"]);	
				 $bin_string = file_get_contents($targetPath.$_FILES["cp_image"]["name"]);
				 $hex_string = base64_encode($bin_string);	
				 unlink($targetPath.$_FILES["cp_image"]["name"]);		
				 $data_to_store = array(
					'cp_name' 		 => $this->security->xss_clean($this->input->post('cp_name')),
					'cp_description' => $this->security->xss_clean($this->input->post('cp_description')),
					'cp_quantity' 	 => $this->security->xss_clean($this->input->post('cp_quantity')),
					'cp_code' 		 => ($this->input->post('cp_quantity') > 0 ? $this->security->xss_clean($this->input->post('cp_code')) : ''),
					'cp_valid_from'  => $this->security->xss_clean($this->input->post('cp_valid_from')),
					'cp_valid_to' 	 => $this->security->xss_clean($this->input->post('cp_valid_to')),
					'customer_id' 	 => $this->security->xss_clean($this->input->post('customer_id')),
					'paid_ads_start_date' => $this->security->xss_clean($this->input->post('paid_ads_start_date')),
					'paid_ads_end_date' => $this->security->xss_clean($this->input->post('paid_ads_end_date')),
					'cp_img_base64' => $hex_string,
					'cp_img_name' => $_FILES["cp_image"]["name"],
				);
				if($this->Coupon_model->addCoupon($data_to_store)){
					$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Successfully added</div>');
				}
				$this->load->view('admin/header');
				$this->load->view('admin/sidebar');
				$this->load->view('admin/coupon/add');
				$this->load->view('admin/footer');
			}
			
		}else{
			
			$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
			$string = '';
			 for ($i = 0; $i < 8; $i++) {
				  $string .= $characters[rand(0, strlen($characters) - 1)];
			 }
			$data['coupon_code'] = $string;
			
			$this->load->view('admin/header');
			$this->load->view('admin/sidebar');
			$this->load->view('admin/coupon/add', $data);
			$this->load->view('admin/footer');
		}
	}
	
	/**
	  * update coupon
	  *
	*/
	public function update(){
		$id = $this->uri->segment(3);
		if(!is_numeric($id)){
			redirect('coupon');
		}
		if ($this->input->server('REQUEST_METHOD') === 'POST')
		{
			$this->form_validation->set_rules('cp_name', ' Coupon Name', 'trim|required');
			$this->form_validation->set_rules('cp_description', ' Description', 'trim|required');
			$this->form_validation->set_rules('cp_quantity', ' Quantity', 'numeric');	
			$this->form_validation->set_rules('cp_code', ' Code', 'trim');	
			$this->form_validation->set_rules('cp_valid_from', ' Valid From', 'trim|required');	
			$this->form_validation->set_rules('cp_valid_to', ' Valid To', 'trim|required');	
			$this->form_validation->set_rules('customer', ' Customer', 'trim|required');	
			$this->form_validation->set_rules('customer_id', ' Customer', 'trim|numeric|required');	
			$this->form_validation->set_error_delimiters('<span class="error">', '</span>'); 
			if ($this->form_validation->run())
			{    
				$hex_string ="";
				if ($_FILES["cp_image"]['size'] >0) {	
				 $targetPath = getcwd() . '/uploads/coupon/';
				 move_uploaded_file($_FILES["cp_image"]["tmp_name"], $targetPath.$_FILES["cp_image"]["name"]);	
				 $bin_string = file_get_contents($targetPath.$_FILES["cp_image"]["name"]);
				 $hex_string = base64_encode($bin_string);		
				 unlink($targetPath.$_FILES["cp_image"]["name"]);		 
				}
							 
				$data_to_store = array(
					'cp_name' 		 => $this->security->xss_clean($this->input->post('cp_name')),
					'cp_description' => $this->security->xss_clean($this->input->post('cp_description')),
					'cp_quantity' 	 => $this->security->xss_clean($this->input->post('cp_quantity')),
					'cp_code' 		 => ($this->input->post('cp_quantity') > 0 ? $this->security->xss_clean($this->input->post('cp_code')) : ''),
					'cp_valid_from'  => $this->security->xss_clean($this->input->post('cp_valid_from')),
					'cp_valid_to' 	 => $this->security->xss_clean($this->input->post('cp_valid_to')),
					'customer_id' 	 => $this->security->xss_clean($this->input->post('customer_id')),
					'cp_status' 	 => $this->security->xss_clean($this->input->post('cp_status')),
					'paid_ads_start_date' => $this->security->xss_clean($this->input->post('paid_ads_start_date')),
					'paid_ads_end_date' => $this->security->xss_clean($this->input->post('paid_ads_end_date')),
				);
				
				if( $hex_string!=""){
					$data_to_store['cp_img_base64'] = $hex_string;
					
					$file_name 						= preg_replace("/[^a-zA-Z0-9.]/", "", $_FILES["cp_image"]["name"]);
					$data_to_store['cp_img_name'] 	= (strlen($file_name) > 200 ? substr($file_name, 0, 200) : $file_name);
				}
				
				//if the insert has returned true then we show the flash message
				if($this->Coupon_model->updateCoupon($id, $data_to_store) === TRUE){
					$this->session->set_flashdata('flash_message', 'updated');
				}else{
					$this->session->set_flashdata('flash_message', 'not_updated');
				}
				redirect('coupon/update/'.$id.'');

			}//validation run

		}

		if($data['coupon'] = $this->Coupon_model->getcouponById($id)){
			
		
			$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
			$string = '';
			 for ($i = 0; $i < 8; $i++) {
				  $string .= $characters[rand(0, strlen($characters) - 1)];
			 }
			$data['coupon_code'] = $string;		
			
		//load the view
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/coupon/update',$data);
		$this->load->view('admin/footer');	
		}else{
			redirect('coupon');
		}
	}
	
	
	/**
    * delete customer
    * @Ei
    */
	function deleteCoupon()
    {
        //product id 
        $id = $this->uri->segment(3);
		$this->Coupon_model->deleteCoupon($id);
       
        redirect('coupon');
    }
}