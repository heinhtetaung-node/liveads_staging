<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
  * Customer Module
  *
  * This module is for Customer function.
  *	@EI EI 
  * @return void
  */
class Customer extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		$this->load->model('Customer_model');
		$this->load->library(array('form_validation','session','pagination'));
        $this->load->helper(array('url','html','form'));
	}
	
	
	function index(){
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/customer/list');
		$this->load->view('admin/footer');
	}
	
	function getCustomer(){
		if (isset($_GET['term'])){
		  $q = strtolower($_GET['term']);
		  $this->Customer_model->getCustomer($q);
		}
	}
	
	function getTag(){
		if (isset($_GET['term'])){
		  $q = strtolower($_GET['term']);
		  $this->Customer_model->getTag($q);
		}
	}
	
	function initTag(){
		if (isset($_GET['id'])){
		  $q = strtolower($_GET['id']);
		  $this->Customer_model->getTag($q);
		}
	}
	
	 /**
    * Add about customer datatable
    * @Ei
    */
	public function customer_datatable(){
		$requestData= $_REQUEST;
 
		$columns = array( 
			0 =>'cu_created',	
			);	
			
		$sql = "SELECT * ";
		$sql.=" FROM customer WHERE 1=1";
		if( !empty($requestData['search']['value']) ) {  
			$sql.=" AND ( cu_name LIKE '".$requestData['search']['value']."%' )";    
		}
		$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";

		$query = $this->db->query($sql);
		//print_r($query->result());
		$recordsFiltered = $this->db->query("SELECT FOUND_ROWS()")->row(0)->{"FOUND_ROWS()"}; 
		//echo $recordsFiltered;
		$resTotalLength = $this->db->query(
			"SELECT COUNT(*) as rowcount FROM customer"

		);
		$recordsTotal = $resTotalLength->row()->rowcount;
		
		$result = $query->result_array();
		$result_array = array();
		foreach ($result as $key => $row) {
			$tmpentry = array();
			$tmpentry[] = $row['cu_name'];
			$tmpentry[] = $row['cu_email'];
			$tmpentry[] = $row['cu_mobile'];			
			$tmpentry[] = $row['cu_lat'];
			$tmpentry[] = $row['cu_long'];
			$tmpentry[] = ($row['cu_status']==1) ? "active" : "inactive";
			$tmpentry[] = "<a href='".base_url()."customer/update/".$row['cu_id']."' class='btn btn-info'>Edit</a><a href='".base_url()."customer/deleteCustomer/".$row['cu_id']."' class='btn btn-danger' onclick='return confirm(\"Are you sure?\")'>Delete</a>";			

			$result_array[] = $tmpentry;
		}
		
		/*
		 * Output
		 */
		$output = array(
			"draw"            => intval( $_GET['draw'] ),
			"recordsTotal"    => intval( $recordsTotal ),
			"recordsFiltered" => intval( $recordsFiltered ),
			"data"            => ($result_array)
		);
		print_r(json_encode($output));
		exit();
	}
	
	
	/**
	  *  add customer
	  *
	*/
	public function add()
	{
		if($this->input->server('REQUEST_METHOD') == 'POST'){
			
			 //form validation			
			$this->form_validation->set_rules('cu_name', ' Name', 'trim|required');
			$this->form_validation->set_rules('cu_email', ' Email', 'trim|valid_email|required');
			$this->form_validation->set_rules('cu_mobile', ' Mobile', 'trim|required');
			$this->form_validation->set_rules('cu_address', 'Address', 'trim|required');
			$this->form_validation->set_rules('cu_postal', 'Postal code', 'trim|required');
			$this->form_validation->set_rules('cu_description', 'Description', 'trim|required');
			$this->form_validation->set_rules('cu_tag', 'Tag', 'trim|required');
			if (empty($_FILES['cu_image']['name']))
				{
					$this->form_validation->set_rules('cu_image', 'Image', 'required');
				}
			$this->form_validation->set_error_delimiters('<span class="error">', '</span>'); 
			if($this->form_validation->run()==FALSE){

				$this->load->view('admin/header');
				$this->load->view('admin/sidebar');
				$this->load->view('admin/customer/add');
				$this->load->view('admin/footer');
			}else{
				$data['tags'] = array_filter(explode(',', $this->security->xss_clean($this->input->post('cu_tag'))));
					 
				 $targetPath = getcwd() . '/uploads/customer/';
				 move_uploaded_file($_FILES["cu_image"]["tmp_name"], $targetPath.$_FILES["cu_image"]["name"]);	
				 $bin_string = file_get_contents($targetPath.$_FILES["cu_image"]["name"]);
				 $hex_string = base64_encode($bin_string);	
				 unlink($targetPath.$_FILES["cu_image"]["name"]);

				 
				 $data_to_store = array(
					'cu_name' => $this->security->xss_clean($this->input->post('cu_name')),
					'cu_email' => $this->security->xss_clean($this->input->post('cu_email')),
					'cu_mobile' => $this->security->xss_clean($this->input->post('cu_mobile')),
					'cu_address' => $this->security->xss_clean($this->input->post('cu_address')),
					'cu_postal' => $this->security->xss_clean($this->input->post('cu_postal')),
					'cu_lat' => $this->security->xss_clean($this->input->post('cu_lat')),
					'cu_long' => $this->security->xss_clean($this->input->post('cu_long')),
					'cu_description' => $this->security->xss_clean($this->input->post('cu_description')),
					'cu_website' => $this->security->xss_clean($this->input->post('cu_website')),
					'cu_logo' => $hex_string,
					'cu_logo_name' => $_FILES["cu_image"]["name"],
				);
				if($id = $this->Customer_model->addCustomer($data_to_store)){
					$this->Customer_model->addCustomerTag($id,$data['tags']);
					redirect(current_url());				
					$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Successfully added</div>');
				}else{
					$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Error saving customer into the system!</div>');
				}
				$this->load->view('admin/header');
				$this->load->view('admin/sidebar');
				$this->load->view('admin/customer/add');
				$this->load->view('admin/footer');
			}
			
		}else{
			$this->load->view('admin/header');
			$this->load->view('admin/sidebar');
			$this->load->view('admin/customer/add');
			$this->load->view('admin/footer');
		}
	}
	
	
	public function update()
	{
		$id = $this->uri->segment(3);
		if(!is_numeric($id)){
			redirect('customer');
		}
		if($this->input->server('REQUEST_METHOD') == 'POST'){
			//form validation			
			$this->form_validation->set_rules('cu_name', ' Name', 'trim|required');
			$this->form_validation->set_rules('cu_email', ' Email', 'trim|valid_email|required');
			$this->form_validation->set_rules('cu_mobile', ' Mobile', 'trim|required');
			$this->form_validation->set_rules('cu_address', 'Address', 'trim|required');
			$this->form_validation->set_rules('cu_postal', 'Postal code', 'trim|required');
			$this->form_validation->set_rules('cu_description', 'Description', 'trim|required');
			$this->form_validation->set_rules('cu_tag', 'Tag', 'trim|required');
			$this->form_validation->set_error_delimiters('<span class="error">', '</span>'); 
			if($this->form_validation->run()==FALSE){
				
				$this->load->view('admin/header');
				$this->load->view('admin/sidebar');
				$this->load->view('admin/customer/update');
				$this->load->view('admin/footer');
			}else{
				$data['tags'] = array_filter(explode(',', $this->security->xss_clean($this->input->post('cu_tag'))));
				$hex_string ="";
				if ($_FILES["cu_image"]['size'] >0) {	
				 $targetPath = getcwd() . '/uploads/customer/';
				 move_uploaded_file($_FILES["cu_image"]["tmp_name"], $targetPath.$_FILES["cu_image"]["name"]);	
				 $bin_string = file_get_contents($targetPath.$_FILES["cu_image"]["name"]);
				 $hex_string = base64_encode($bin_string);		
				 unlink($targetPath.$_FILES["cu_image"]["name"]);					 
				}	
				 $data_to_store = array(
					'cu_name' => $this->security->xss_clean($this->input->post('cu_name')),
					'cu_email' => $this->security->xss_clean($this->input->post('cu_email')),
					'cu_mobile' => $this->security->xss_clean($this->input->post('cu_mobile')),
					'cu_address' => $this->security->xss_clean($this->input->post('cu_address')),
					'cu_postal' => $this->security->xss_clean($this->input->post('cu_postal')),
					'cu_lat' => $this->security->xss_clean($this->input->post('cu_lat')),
					'cu_long' => $this->security->xss_clean($this->input->post('cu_long')),
					'cu_description' => $this->security->xss_clean($this->input->post('cu_description')),
					'cu_website' => $this->security->xss_clean($this->input->post('cu_website')),
				);
				if( $hex_string!=""){
					$data_to_store['cu_logo'] = $hex_string;
					
					$file_name 						= preg_replace("/[^a-zA-Z0-9.]/", "", $_FILES["cu_image"]["name"]);
					$data_to_store['cu_logo_name'] 	= (strlen($file_name) > 200 ? substr($file_name, 0, 200) : $file_name);
				}
				if($data['tags'] != ""){
					if($this->Customer_model->deleteCustomerTag($id)){
						$this->Customer_model->addCustomerTag($id,$data['tags']);
					}					
				}
				if($this->Customer_model->updateCustomer($id, $data_to_store)){
					
					$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Successfully update customer.</div>');
				}else{
					$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Error updating customer into the system!</div>');
				}
				//redirect('customer/update/'.$id.'');
			}
			
		}
		

		if($data['customer'] = $this->Customer_model->getCustomerDataById($id)){
			$tag = $this->Customer_model->initTag($data['customer']->cu_id);
			//['Hello', 'World', 'Example', 'Tags']
			$data['tag_array_string'] ="";
			$data['tag_comma_string'] ="";
			if(count($tag) >0 ){
				$data['tag_array_string'].= '[';
				for($i=0; $i <count($tag);$i++){
					$data['tag_array_string'].= "'".$tag[$i] ."'," ;
					$data['tag_comma_string'].= $tag[$i] ."," ;
				}
				$data['tag_array_string'] = substr($data['tag_array_string'], 0,-1);
				$data['tag_comma_string'] = substr($data['tag_comma_string'], 0,-1);
				$data['tag_array_string'].= ']';
			}
			//load the view
			$this->load->view('admin/header');
			$this->load->view('admin/sidebar');
			$this->load->view('admin/customer/update', $data);
			$this->load->view('admin/footer');	
		}else{
			redirect('customer');
		}
		
	}
	

	
	/**
    * delete customer
    * @Ei
    */
	function deleteCustomer()
    {
        //product id 
        $id = $this->uri->segment(3);
		$this->Customer_model->deleteCustomer($id);
       
        redirect('customer');
    }
	
}