<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
  * Event Module
  *
  * This module is for Customer function.
  *	@EI EI 
  * @return void
  */
class Event extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		$this->load->model('Event_model');
		$this->load->library(array('form_validation','session','pagination'));
        $this->load->helper(array('url','html','form'));
	}
	
	 /**
    * Add about event list
    * @Ei
    */
	function index(){
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/event/list');
		$this->load->view('admin/footer');
	}
	
	
	 /**
    * Add about event datatable
    * @Ei
    */
	public function event_datatable(){
		$requestData= $_REQUEST;
 
		$columns = array( 
			0 =>'ev_created',	
			);	
			
		$sql = "SELECT customer.cu_name,
				`event`.ev_id,
				`event`.customer_id,
				`event`.ev_title,
				`event`.ev_location,
				`event`.ev_img_base64,
				`event`.ev_description,
				`event`.ev_link,
				`event`.ev_date,
				`event`.ev_like_count,
				`event`.ev_created,
				`event`.ev_status";
		$sql.=" FROM
				`event`
				INNER JOIN customer ON `event`.customer_id = customer.cu_id WHERE 1=1";
		if( !empty($requestData['search']['value']) ) {  
			$sql.=" AND ( `event`.ev_title LIKE '".$requestData['search']['value']."%' )";    
		}
		$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";

		$query = $this->db->query($sql);
		//print_r($query->result());
		$recordsFiltered = $this->db->query("SELECT FOUND_ROWS()")->row(0)->{"FOUND_ROWS()"}; 
		//echo $recordsFiltered;
		$resTotalLength = $this->db->query(
			"SELECT COUNT(*) as rowcount FROM event"

		);
		$recordsTotal = $resTotalLength->row()->rowcount;
		
		$result = $query->result_array();
		$result_array = array();
		foreach ($result as $key => $row) {
			$tmpentry = array();
			$tmpentry[] = $row['ev_title'];
			$tmpentry[] = $row['cu_name'];
			$tmpentry[] = $row['ev_location'];			
			$tmpentry[] = $row['ev_date'];
			$tmpentry[] = "<a href='".base_url()."event/update/".$row['ev_id']."' class='btn btn-info'>Edit</a><a href='".base_url()."event/deleteEvent/".$row['ev_id']."' class='btn btn-danger' onclick='return confirm(\"Are you sure?\")'>Delete</a>";			

			$result_array[] = $tmpentry;
		}
		
		/*
		 * Output
		 */
		$output = array(
			"draw"            => intval( $_GET['draw'] ),
			"recordsTotal"    => intval( $recordsTotal ),
			"recordsFiltered" => intval( $recordsFiltered ),
			"data"            => ($result_array)
		);
		print_r(json_encode($output));
		exit();
	}
	
	
	/**
	  *  add event
	  *
	*/
	public function add()
	{
		if($this->input->server('REQUEST_METHOD') == 'POST'){
			 //form validation			
			$this->form_validation->set_rules('ev_title', ' Title', 'trim|required');
			$this->form_validation->set_rules('ev_location', ' Locaton', 'trim|required');
			$this->form_validation->set_rules('ev_description', ' Description', 'trim|required');
			$this->form_validation->set_rules('ev_date', ' Date', 'trim|required');	
			$this->form_validation->set_rules('customer', ' Customer', 'trim|required');	
			$this->form_validation->set_rules('customer_id', ' Customer', 'trim|numeric|required');	
			if (empty($_FILES['ev_image']['name']))
			{
				$this->form_validation->set_rules('ev_image', 'Image', 'required');
			}
			$this->form_validation->set_error_delimiters('<span class="error">', '</span>'); 
			if($this->form_validation->run()==FALSE){
				
				$this->load->view('admin/header');
				$this->load->view('admin/sidebar');
				$this->load->view('admin/event/add');
				$this->load->view('admin/footer');
			}else{		
				 $targetPath = getcwd() . '/uploads/event/';
				 $temp = explode(".", $_FILES["ev_image"]["name"]);
				 $newfilename = round(microtime(true)) . '.' . end($temp);	
				 move_uploaded_file($_FILES["ev_image"]["tmp_name"], $targetPath.$newfilename);	
				 $bin_string = file_get_contents($targetPath.$newfilename);
				 $hex_string = base64_encode($bin_string);	
				 unlink($targetPath.$newfilename);	
				 $data_to_store = array(
					'ev_title' => $this->security->xss_clean($this->input->post('ev_title')),
					'ev_location' => $this->security->xss_clean($this->input->post('ev_location')),
					'ev_description' => $this->security->xss_clean($this->input->post('ev_description')),
					'ev_date' => $this->security->xss_clean($this->input->post('ev_date')),
					'ev_link' => $this->security->xss_clean($this->input->post('ev_link')),
					'customer_id' => $this->security->xss_clean($this->input->post('customer_id')),
					'paid_ads_start_date' => $this->security->xss_clean($this->input->post('paid_ads_start_date')),
					'paid_ads_end_date' => $this->security->xss_clean($this->input->post('paid_ads_end_date')),
					'ev_img_base64' => $hex_string,
					'ev_img_name' => $_FILES["ev_image"]["name"],
				);
				if($this->Event_model->addEvent($data_to_store)){
					$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Successfully added</div>');
				}
				$this->load->view('admin/header');
				$this->load->view('admin/sidebar');
				$this->load->view('admin/event/add');
				$this->load->view('admin/footer');
			}
			
		}else{
			
			$this->load->view('admin/header');
			$this->load->view('admin/sidebar');
			$this->load->view('admin/event/add');
			$this->load->view('admin/footer');
		}
	}
	
	/**
	  * update event
	  *
	*/
	public function update(){
		$id = $this->uri->segment(3);
		if(!is_numeric($id)){
			redirect('event');
		}
		if ($this->input->server('REQUEST_METHOD') === 'POST')
		{
			$this->form_validation->set_rules('ev_title', ' Title', 'trim|required');
			$this->form_validation->set_rules('ev_location', ' Locaton', 'trim|required');
			$this->form_validation->set_rules('ev_description', ' Description', 'trim|required');
			$this->form_validation->set_rules('ev_date', ' Date', 'trim|required');	
			$this->form_validation->set_rules('customer', ' Customer', 'trim|required');	
			$this->form_validation->set_rules('customer_id', ' Customer', 'trim|numeric|required');
			$this->form_validation->set_error_delimiters('<span class="error">', '</span>'); 
			if ($this->form_validation->run())
			{    
				$hex_string ="";
				if ($_FILES["ev_image"]['size'] >0) {	
				 $targetPath = getcwd() . '/uploads/event/';
				 $newfilename = round(microtime(true)) . '.' . end($temp);	
				 move_uploaded_file($_FILES["ev_image"]["tmp_name"], $targetPath.$newfilename);	
				 $bin_string = file_get_contents($targetPath.$newfilename);
				 $hex_string = base64_encode($bin_string);	
				 unlink($targetPath.$newfilename);					 
				}	
							 
				 $data_to_store = array(
					'ev_title' => $this->security->xss_clean($this->input->post('ev_title')),
					'ev_location' => $this->security->xss_clean($this->input->post('ev_location')),
					'ev_description' => $this->security->xss_clean($this->input->post('ev_description')),
					'ev_date' => $this->security->xss_clean($this->input->post('ev_date')),
					'ev_link' => $this->security->xss_clean($this->input->post('ev_link')),
					'customer_id' => $this->security->xss_clean($this->input->post('customer_id')),
					'paid_ads_start_date' => $this->security->xss_clean($this->input->post('paid_ads_start_date')),
					'paid_ads_end_date' => $this->security->xss_clean($this->input->post('paid_ads_end_date')),
					'ev_status' => $this->input->post('ev_status'),
				);
				
				if( $hex_string!=""){
					$data_to_store['ev_img_base64'] = $hex_string;
					
					$file_name 						= preg_replace("/[^a-zA-Z0-9.]/", "", $_FILES["ev_image"]["name"]);
					$data_to_store['ev_img_name'] 	= (strlen($file_name) > 200 ? substr($file_name, 0, 200) : $file_name);
				}
				//if the insert has returned true then we show the flash message
				if($this->Event_model->updateEvent($id, $data_to_store) == TRUE){
					$this->session->set_flashdata('flash_message', 'updated');
				}else{
					$this->session->set_flashdata('flash_message', 'not_updated');
				}
				redirect('event/update/'.$id.'');

			}//validation run

		}

		if($data['event'] = $this->Event_model->getEventById($id)){
			$this->load->view('admin/header');
			$this->load->view('admin/sidebar');
			$this->load->view('admin/event/update',$data);
			$this->load->view('admin/footer');	
		}else{
			redirect('event');
		}
		//print_r($data);
		//load the view
		
	}
	
	
	/**
    * delete event
    * @Ei
    */
	function deleteEvent()
    {
        //product id 
        $id = $this->uri->segment(3);
		$this->Event_model->deleteEvent($id);
       
        redirect('event');
    }
}