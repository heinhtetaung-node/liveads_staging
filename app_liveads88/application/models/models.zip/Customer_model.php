<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer_Model extends CI_Model
{
	function getCustomer($q){
		$this->db->select('*');
		$this->db->like('cu_name', $q);
		$query = $this->db->get('customer');
		if($query->num_rows() > 0){
		  foreach ($query->result_array() as $row){
			$new_row['id']=(int)$row['cu_id'];
			$new_row['value']=htmlentities(stripslashes($row['cu_name']));
			$new_row['label']=htmlentities(stripslashes($row['cu_name']));
			$row_set[] = $new_row; //build an array
		  }
		  echo json_encode($row_set); //format the array into json data
		}
	}
	
	function getTag($q){
		$this->db->select('*');
		$this->db->like('tg_name', $q);
		$query = $this->db->get('tag');
		if($query->num_rows() > 0){
		  foreach ($query->result_array() as $row){
			$new_row['id']=(int)$row['tg_id'];
			$new_row['value']=htmlentities(stripslashes($row['tg_name']));
			$new_row['label']=htmlentities(stripslashes($row['tg_name']));
			$row_set[] = $new_row; //build an array
		  }
		  echo json_encode($row_set); //format the array into json data
		}
	}
	
	function initTag($id){
		$sql = "SELECT
				tag.tg_name
				FROM
				customer_tag
				INNER JOIN tag ON tag.tg_id = customer_tag.tg_id
				WHERE
				customer_tag.cu_id =".$id;

		$query = $this->db->query($sql);
		if($query->num_rows() > 0){
			  foreach ($query->result_array() as $row){
				$new_row[] = $row['tg_name'];
			  }
			  return $new_row;
		}
	}
	
	function deleteCustomerTag($id){
		$this->db->where('cu_id', $id);
		$this->db->delete('customer_tag'); 
		return true;
		
	}
	function addCustomer($data){
		$this->db->set('cu_created', 'NOW()', FALSE);
		$this->db->insert('customer', $data);
		$id = $this->db->insert_id();
		return $id;		
	}
	
	function updateCustomer($id,$data){
		//print_r($data);
		$this->db->where('cu_id', $id);
		$this->db->update('customer',$data);
		return true;
	}
	
	function getCustomerDataById($cu_id){
		$this->db->select('*');
		$this->db->where('cu_id', $cu_id);
		$query = $this->db->get('customer');
		if($query->num_rows() > 0){
			return $query->row();
		}
		return false;
	}
	
	function deleteCustomer($id){
		$this->db->where('cu_id', $id);
		$this->db->delete('customer'); 
	}
	
	function check_customer($id){
		$this->db->select('*');
		$this->db->where('cu_id', $id);
		$query = $this->db->get('customer');
		if($query->num_rows() > 0){
			return true;
		}
		return false;
	}
	
	function check_tag($name){
		$this->db->select('*');
		$this->db->where('tg_name', $name);
		$query = $this->db->get('tag');
		if($query->num_rows() > 0){
			return $query->row();
		}
	}
	
	function addCustomerTag($cu_id,$tags){
		foreach($tags as $tag){
		    $data = $this->check_tag($tag);
			if($data = $this->check_tag($tag)){
				if($data->tg_name == $tag){
				$this->db->set('cu_id', $cu_id);
				$this->db->set('tg_id', $data->tg_id);
				$this->db->insert('customer_tag');
				}
			}else{
				$this->db->set('tg_name', $tag);
				$this->db->insert('tag');
				$tag_id = $this->db->insert_id();
				$this->db->set('cu_id', $cu_id);
				$this->db->set('tg_id', $tag_id);
				$this->db->insert('customer_tag');
			}		
			
		}
	}
}