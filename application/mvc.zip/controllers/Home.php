<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
  * Customer Module
  *
  * This module is for Customer function.
  *	@EI EI 
  * @return void
  */
class Home extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		$this->load->model('Customer_model');
		$this->load->model('Product_model');
		$this->load->library(array('form_validation','session','pagination'));
        $this->load->helper(array('url','html','form'));
	}
	
	
	function index(){
		
		$brands = $this->Product_model->apiGetBrands();
		$hometopbanner = $this->Product_model->getHomeTopBanner();
		$homebottombanner = $this->Product_model->getHomeTopBanner();
		$promotion_item = $this->Product_model->getPromotionList('');

		$data['brands'] = $brands;		 
		$data['topbanners'] = $hometopbanner;		 
		$data['bottombanners'] = $homebottombanner;		 
		$data['promotion_items'] = $promotion_item;		 
		$this->load->view('header');
		$this->load->view('home', $data);
		$this->load->view('footer');
	}
	
	function getNews(){
		$news = $this->Product_model->apiGetFlashNews();
		print_r(json_encode($news));
		
	}
	
}